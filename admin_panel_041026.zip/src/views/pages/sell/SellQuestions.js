﻿import React, { useState, useEffect, useMemo } from "react";
import ThemedTablePage from 'src/components/ThemedTablePage'
import CIcon from "@coreui/icons-react";
import {
    cilPlus, cilX, cilCheck, cilPencil, cilTrash, cilChevronRight,
    cilReload, cilArrowRight, cilLink
} from "@coreui/icons";
import {
    get_sell_questions, create_sell_question, update_sell_question, delete_sell_question,
    create_question_option, update_question_option, delete_question_option,
    get_question_conditions, create_question_condition, delete_question_condition,
    get_categories, map_question_to_category, unmap_question_from_category,
    get_sell_question_contexts, upload_sell_image
} from "../../../api/system_service";

const INPUT_TYPES = [
    { value: "yes_no", label: "Yes / No" },
    { value: "single_select", label: "Single Select" },
    { value: "multi_select", label: "Multi Select" },
];

const DEFAULT_CONTEXTS = [
    { id: 1, option_name: 'sell' },
    { id: 2, option_name: 'inspection' },
    { id: 3, option_name: 'both' },
]

const contextBadge = (slug) => {
    const raw = String(slug ?? '').trim().toLowerCase()
    const s = (raw === '1') ? 'sell' : (raw === '2') ? 'inspection' : (raw === '3') ? 'both' : raw
    const map = { sell: 'bg-success', inspection: 'bg-secondary', both: 'bg-dark' }
    if (!s) return null
    return <span className={`badge ${map[s] || 'bg-light text-dark border'}`} style={{ fontSize: '0.68rem' }}>{s}</span>
}

// yes_no placeholder options — shown when DB options haven't loaded yet
const YES_NO_DEFAULTS = [
    { id: null, text: "Yes", price_deduction: 0, sort_index: 1, show: [], _synthetic: true },
    { id: null, text: "No", price_deduction: 0, sort_index: 2, show: [], _synthetic: true },
];

/**
 * Normalize a raw option from the API.
 * Handles both field naming conventions: price_deduction vs deduction.
 * Ensures `show` is always an array of strings.
 */
const normalizeOption = (o = {}) => ({
    ...o,
    id: o.id ?? null,
    text: o.text ?? "",
    price_deduction: Number(o.price_deduction ?? o.deduction ?? 0),
    sort_index: o.sort_index ?? 0,
    show: Array.isArray(o.show) ? o.show.map(String) : [],
    option_image_id: o.option_image_id ?? null,
    option_image_url: o.option_image_url ?? null,
});

/**
 * Normalize a raw question from the API.
 * Ensures options, categories are always arrays and IDs are strings.
 */
const normalizeQuestion = (q = {}) => ({
    ...q,
    id: String(q.id ?? ""),
    text: q.text ?? "",
    description: q.description ?? "",
    input_type: q.input_type ?? "single_select",
    context_label: q.context_label ?? q.context_slug ?? q.context ?? null,
    sort_index: q.sort_index ?? q.index ?? 0,
    options: Array.isArray(q.options) ? q.options.map(normalizeOption) : [],
    categories: Array.isArray(q.categories) ? q.categories : [],
});

/** Effective options for a question — always returns Yes/No stubs for yes_no type. */
const getEffectiveOptions = (q) => {
    if (!q) return [];
    if (q.input_type !== "yes_no") return q.options ?? [];
    return (q.options?.length > 0) ? q.options : YES_NO_DEFAULTS;
};

const inputTypeBadge = (type) => {
    const map = { yes_no: "bg-info", single_select: "bg-primary", multi_select: "bg-warning text-dark" };
    return <span className={`badge ${map[type] || "bg-secondary"}`}>{(type ?? "").replace(/_/g, " ")}</span>;
};

export default function SellQuestions() {
    const [toast, setToast] = useState(null);
    const showToast = (type, msg) => {
        setToast({ type, msg });
        window.clearTimeout(showToast._t);
        showToast._t = window.setTimeout(() => setToast(null), 3500);
    };

    const [questions, setQuestions] = useState([]);
    const [categories, setCategories] = useState([]);
    const [contexts, setContexts] = useState(DEFAULT_CONTEXTS)
    const [activeContext, setActiveContext] = useState('sell') // sell | inspection | both
    const [loading, setLoading] = useState(false);
    const [showAdd, setShowAdd] = useState(false);
    const [saving, setSaving] = useState(false);
    const [expandedId, setExpandedId] = useState(null);

    // Inline edit state
    const [editingId, setEditingId] = useState(null);
    const [editData, setEditData] = useState({ text: "", description: "", input_type: "single_select", context: 'sell', sort_index: 1, category_slugs: [] });

    // Add question form
    const [newQ, setNewQ] = useState({ text: "", description: "", input_type: "yes_no", context: 'sell', category_slugs: [] });
    const [addAttempted, setAddAttempted] = useState(false);

    // Options â€” shared add form; keyed by expanded question
    const [newOpt, setNewOpt] = useState({ text: "", price_deduction: 0 });
    const [savingOpt, setSavingOpt] = useState(false);
    const [optDeductionDraft, setOptDeductionDraft] = useState({});
    const [savingDeductionId, setSavingDeductionId] = useState(null);

    // Option image attach
    const [optImageTargetId, setOptImageTargetId] = useState("")
    const [optImageFile, setOptImageFile] = useState(null)
    const [uploadingOptImage, setUploadingOptImage] = useState(false)

    // Condition add form
    const [newCond, setNewCond] = useState({ trigger_option_id: "", show_question_id: "" });

    // Category mapping
    const [mapCatSlug, setMapCatSlug] = useState("");

    // ── Filters ────────────────────────────────────────────
    const [filterText, setFilterText] = useState("");
    const [filterCategory, setFilterCategory] = useState("");
    const [filterType, setFilterType] = useState("");
    const [filterConditional, setFilterConditional] = useState(""); // "" | "yes" | "no"

    useEffect(() => {
        fetchCategories();
        fetchContexts();
    }, []);

    useEffect(() => {
        fetchQuestions();
        setExpandedId(null)
        setEditingId(null)
        setShowAdd(false)
        setAddAttempted(false)
        setNewQ(p => ({ ...p, context: activeContext }))
    }, [activeContext]);

    //  Derived data 

    /**
     * Set of question IDs that are referenced in at least one option's `show` array.
     * These questions are conditional â€” they don't appear by default in the sell flow.
     */
    const conditionalQIds = useMemo(() => {
        const ids = new Set();
        questions.forEach(q => {
            (q.options ?? []).forEach(o => {
                (o.show ?? []).forEach(id => ids.add(String(id)));
            });
        });
        return ids;
    }, [questions]);

    /** Whether any filter is currently active */
    const hasActiveFilters = filterText !== "" || filterCategory !== "" || filterType !== "" || filterConditional !== "";

    /** Filtered questions based on current filter state */
    const filteredQuestions = useMemo(() => {
        return questions.filter(q => {
            if (filterText) {
                const t = filterText.toLowerCase();
                if (
                    !q.text?.toLowerCase().includes(t) &&
                    !q.description?.toLowerCase().includes(t)
                ) return false;
            }
            if (filterCategory) {
                const matchedCat = categories.find(c => c.slug === filterCategory);
                if (matchedCat && !(q.categories ?? []).some(qc => qc.id === matchedCat.id)) return false;
            }
            if (filterType && q.input_type !== filterType) return false;
            if (filterConditional === "yes" && !conditionalQIds.has(String(q.id))) return false;
            if (filterConditional === "no" && conditionalQIds.has(String(q.id))) return false;
            return true;
        });
    }, [questions, filterText, filterCategory, filterType, filterConditional, conditionalQIds, categories]);

    /** Reset all filters */
    const clearFilters = () => {
        setFilterText("");
        setFilterCategory("");
        setFilterType("");
        setFilterConditional("");
    };

    /**
     * For a given question, find which options (from other questions) trigger its appearance.
     * Returns: [{ fromQuestion, option }]
     */
    const getTriggeredBy = (questionId) => {
        const qId = String(questionId);
        const triggers = [];
        questions.forEach(q => {
            (q.options ?? []).forEach(o => {
                if ((o.show ?? []).includes(qId)) {
                    triggers.push({ fromQuestion: q, option: o });
                }
            });
        });
        return triggers;
    };

    /**
     * Outgoing conditions for a question derived from its options' `show` arrays.
     * Returns: [{ option, shownQuestion }]
     */
    const getOutgoingConditions = (q) => {
        const results = [];
        (q?.options ?? []).forEach(o => {
            (o.show ?? []).forEach(shownId => {
                const shownQ = questions.find(oq => String(oq.id) === String(shownId));
                if (shownQ) results.push({ option: o, shownQuestion: shownQ });
            });
        });
        return results;
    };

    //  Fetch helpers 

    const fetchQuestions = async () => {
        try {
            setLoading(true);
            const res = await get_sell_questions({ context: activeContext });
            const raw = Array.isArray(res.data) ? res.data : [];
            setQuestions(raw.map(normalizeQuestion));
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to load questions');
            setQuestions([]);
        } finally {
            setLoading(false);
        }
    };

    const fetchContexts = async () => {
        try {
            const res = await get_sell_question_contexts()
            const raw = Array.isArray(res.data) ? res.data : []
            const cleaned = raw
                .map(r => ({ id: r.id, option_name: String(r.option_name || '').toLowerCase() }))
                .filter(r => !!r.option_name)
            setContexts(cleaned.length ? cleaned : DEFAULT_CONTEXTS)
        } catch (e) {
            setContexts(DEFAULT_CONTEXTS)
        }
    }

    const fetchCategories = async () => {
        try {
            const res = await get_categories("true");
            setCategories(Array.isArray(res.data) ? res.data : []);
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to load categories');
        }
    };

    const buildQuestionPayload = (data, sortIndex) => ({
        text: (data.text ?? "").trim(),
        description: (data.description ?? "").trim() || null,
        input_type: data.input_type,
        context: data.context || activeContext,
        sort_index: parseInt(sortIndex) || 1,
        category_slugs: Array.isArray(data.category_slugs) ? data.category_slugs.map(String).filter(Boolean) : [],
    });

    const handleCreateQuestion = async () => {
        setAddAttempted(true);
        if (!newQ.text?.trim()) return showToast('danger', 'Question text is required');
        if (!newQ.input_type) return showToast('danger', 'Input type is required');
        if (!Array.isArray(newQ.category_slugs) || newQ.category_slugs.length === 0) {
            return showToast('danger', 'Select at least one category before saving');
        }
        try {
            setSaving(true);
            const nextSortIndex = (questions.length > 0
                ? Math.max(...questions.map(q => q.sort_index))
                : 0) + 1;
            await create_sell_question(buildQuestionPayload(newQ, nextSortIndex));
            setShowAdd(false);
            setNewQ({ text: "", description: "", input_type: "yes_no", context: activeContext, category_slugs: [] });
            setAddAttempted(false);
            showToast('success', 'Question created');
            fetchQuestions();
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to create question');
        } finally {
            setSaving(false);
        }
    };

    const handleUpdateOptionDeduction = async (opt) => {
        if (!opt?.id) return;
        try {
            setSavingDeductionId(String(opt.id));
            const raw = optDeductionDraft[String(opt.id)];
            const pct = Math.min(100, Math.max(0, parseFloat(raw) || 0));
            await update_question_option(opt.id, { price_deduction: pct });
            showToast('success', 'Deduction updated');
            fetchQuestions();
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to update deduction');
        } finally {
            setSavingDeductionId(null);
        }
    };

    const startEditing = (q) => {
        setEditingId(q.id);
        setEditData({
            text: q.text ?? "",
            description: q.description ?? "",
            input_type: q.input_type ?? "single_select",
            context: String(q.context_label || q.context || activeContext).toLowerCase(),
            sort_index: q.sort_index ?? 1,
            category_slugs: Array.isArray(q.categories)
                ? q.categories
                      .map(c => (typeof c === 'string' ? c : (c?.slug ?? (c?.id ? String(c.id) : null))))
                      .filter(Boolean)
                : [],
        });
    };

    const toggleEditCategory = (catSlug) => {
        const slug = String(catSlug || '').trim();
        if (!slug) return;
        setEditData(prev => ({
            ...prev,
            category_slugs: (prev.category_slugs ?? []).includes(slug)
                ? prev.category_slugs.filter(s => s !== slug)
                : [...(prev.category_slugs ?? []), slug],
        }));
    };

    const handleUpdateQuestion = async () => {
        if (!editData.text?.trim()) return showToast('danger', 'Question text is required');
        if (!Array.isArray(editData.category_slugs) || editData.category_slugs.length === 0) {
            return showToast('danger', 'Select at least one category');
        }
        try {
            setSaving(true);
            await update_sell_question(editingId, buildQuestionPayload(editData, editData.sort_index));
            setEditingId(null);
            showToast('success', 'Question updated');
            fetchQuestions();
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to update question');
        } finally {
            setSaving(false);
        }
    };

    const handleDeleteQuestion = async (id) => {
        if (!window.confirm('Are you sure want to delete this?')) return;
        try {
            await delete_sell_question(id);
            if (expandedId === id) { setExpandedId(null); }
            showToast('success', 'Question deactivated');
            fetchQuestions();
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to deactivate question');
        }
    };

    const toggleExpand = (q) => {
        const qId = String(q.id);
        if (expandedId === qId) {
            setExpandedId(null);
            setOptImageTargetId("")
            setOptImageFile(null)
        } else {
            setExpandedId(qId);
            setEditingId(null);
            setNewOpt({ text: "", price_deduction: 0 });
            setNewCond({ trigger_option_id: "", show_question_id: "" });
            setOptImageTargetId("")
            setOptImageFile(null)
            // Prime drafts for option deductions
            const nextDrafts = {};
            (getEffectiveOptions(q) ?? []).forEach(o => {
                if (o?.id) nextDrafts[String(o.id)] = Number(o.price_deduction ?? 0);
            });
            setOptDeductionDraft(nextDrafts);
        }
    };

    //  Option CRUD 

    const handleAddOption = async (questionId) => {
        if (!newOpt.text?.trim()) return showToast('danger', 'Option text is required');
        try {
            setSavingOpt(true);
            const question = questions.find(q => String(q.id) === String(questionId));
            const nextOptSort = (question?.options?.length ?? 0) + 1;
            const deductionPct = Math.min(100, Math.max(0, parseFloat(newOpt.price_deduction) || 0));
            await create_question_option({
                question_id: questionId,
                text: newOpt.text.trim(),
                price_deduction: deductionPct,
                sort_index: nextOptSort,
            });
            setNewOpt({ text: "", price_deduction: 0 });
            showToast('success', 'Option added');
            fetchQuestions();
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to add option');
        } finally {
            setSavingOpt(false);
        }
    };

    const handleDeleteOption = async (optId) => {
        if (!optId) return;
        if (!window.confirm('Are you sure want to delete this?')) return;
        try {
            await delete_question_option(optId);
            showToast('success', 'Option deleted');
            fetchQuestions();
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to delete option');
        }
    };

    const handleAttachOptionImage = async () => {
        if (!optImageTargetId) return showToast('danger', 'Select an option to attach image');
        if (!optImageFile) return showToast('danger', 'Choose an image file');
        try {
            setUploadingOptImage(true);
            const fd = new FormData();
            fd.append('image', optImageFile);
            fd.append('alt_text', 'Sell option image');
            const imgRes = await upload_sell_image(fd);
            const imageId = imgRes?.data?.id;
            if (!imageId) throw new Error('Upload did not return image id');

            await update_question_option(optImageTargetId, { option_image_id: imageId });
            showToast('success', 'Option image attached');
            setOptImageFile(null);
            fetchQuestions();
        } catch (e) {
            showToast('danger', e?.response?.data?.message || e?.message || 'Failed to attach option image');
        } finally {
            setUploadingOptImage(false);
        }
    };

    const handleClearOptionImage = async (optId) => {
        if (!optId) return;
        try {
            setUploadingOptImage(true);
            await update_question_option(optId, { option_image_id: null });
            showToast('success', 'Option image cleared');
            fetchQuestions();
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to clear option image');
        } finally {
            setUploadingOptImage(false);
        }
    };

    //  Condition CRUD â”€

    const handleAddCondition = async () => {
        if (!newCond.trigger_option_id || !newCond.show_question_id) {
            return showToast('danger', 'Select both an option and a question to show');
        }
        try {
            await create_question_condition({
                trigger_option_id: parseInt(newCond.trigger_option_id),
                show_question_id: parseInt(newCond.show_question_id),
            });
            setNewCond({ trigger_option_id: "", show_question_id: "" });
            showToast('success', 'Condition added');
            fetchQuestions(); // refresh show[] arrays
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to add condition');
        }
    };

    const handleDeleteCondition = async (triggerOptionId, showQuestionId) => {
        if (!triggerOptionId || !showQuestionId || !expandedId) return;
        if (!window.confirm('Are you sure want to delete this?')) return;
        try {
            // Fetch condition ID on demand (no need to pre-load conditions)
            const res = await get_question_conditions(expandedId);
            const cond = (Array.isArray(res.data) ? res.data : []).find(c =>
                String(c.trigger_option_id) === String(triggerOptionId) &&
                String(c.show_question_id) === String(showQuestionId)
            );
            if (!cond?.id) return;
            await delete_question_condition(cond.id);
            showToast('success', 'Condition removed');
            fetchQuestions(); // refresh show[] arrays
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to remove condition');
        }
    };


    const handleMapCategory = async (questionId) => {
        if (!mapCatSlug) return showToast('danger', 'Select a category to map');
        try {
            await map_question_to_category({ category_slug: mapCatSlug, question_id: questionId });
            setMapCatSlug("");
            showToast('success', 'Category mapped');
            fetchQuestions();
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to map category');
        }
    };

    const handleUnmapCategory = async (categoryId, questionId) => {
        try {
            await unmap_question_from_category(categoryId, questionId);
            showToast('success', 'Category unmapped');
            fetchQuestions();
        } catch (e) {
            showToast('danger', e?.response?.data?.message || 'Failed to unmap category');
        }
    };

    const toggleCategory = (catSlug) => {
        setNewQ(prev => ({
            ...prev,
            category_slugs: (prev.category_slugs ?? []).includes(catSlug)
                ? prev.category_slugs.filter(s => s !== catSlug)
                : [...(prev.category_slugs ?? []), catSlug],
        }));
    };



    const nextSortIndex = questions.length > 0
        ? Math.max(...questions.map(q => q.sort_index ?? 0)) + 1
        : 1;

    return (
        <div className="container py-4">
            {toast && (
                <div
                    className={`alert alert-${toast.type} alert-dismissible position-fixed top-0 end-0 m-3 shadow`}
                    style={{ zIndex: 9999, minWidth: 300 }}
                >
                    <span>{toast.msg}</span>
                    <button className="btn-close" onClick={() => setToast(null)} />
                </div>
            )}

            <ThemedTablePage
                loading={loading}
                actions={{
                    filtersContent: (
                        <div className="d-flex flex-column gap-2">
                            <div>
                                <label className="form-label small fw-semibold mb-1">Search</label>
                                <input
                                    type="text"
                                    className="form-control form-control-sm"
                                    placeholder="Search by question text or description..."
                                    value={filterText}
                                    onChange={e => setFilterText(e.target.value)}
                                />
                            </div>

                            <div>
                                <label className="form-label small fw-semibold mb-1">Category</label>
                                <select
                                    className="form-select form-select-sm"
                                    value={filterCategory}
                                    onChange={e => setFilterCategory(e.target.value)}
                                >
                                    <option value="">All Categories</option>
                                    {categories.map(c => (
                                        <option key={c.slug} value={c.slug}>{c.name}</option>
                                    ))}
                                </select>
                            </div>

                            <div>
                                <label className="form-label small fw-semibold mb-1">Type</label>
                                <select
                                    className="form-select form-select-sm"
                                    value={filterType}
                                    onChange={e => setFilterType(e.target.value)}
                                >
                                    <option value="">All Types</option>
                                    {INPUT_TYPES.map(t => (
                                        <option key={t.value} value={t.value}>{t.label}</option>
                                    ))}
                                </select>
                            </div>

                            <div>
                                <label className="form-label small fw-semibold mb-1">Visibility</label>
                                <select
                                    className="form-select form-select-sm"
                                    value={filterConditional}
                                    onChange={e => setFilterConditional(e.target.value)}
                                >
                                    <option value="">All</option>
                                    <option value="no">Default (always shown)</option>
                                    <option value="yes">Conditional only</option>
                                </select>
                            </div>

                            <button
                                type="button"
                                className="btn btn-sm btn-outline-secondary"
                                onClick={clearFilters}
                                disabled={!hasActiveFilters}
                                title="Clear filters"
                            >
                                <CIcon icon={cilX} className="me-1" />
                                Reset
                            </button>
                        </div>
                    ),
                    onExport: null,
                }}
                topContent={
                    <div className="mb-3">
                        <div className="d-flex justify-content-between align-items-start flex-wrap gap-2">
                            <div>
                                <h4 className="fw-bold text-uppercase mb-0">Sell Questions</h4>
                                <small className="text-muted">
                                    Manage evaluation questions, options, conditions &amp; category mappings
                                </small>
                            </div>
                            <div className="d-flex gap-2">
                                <button
                                    type="button"
                                    className="btn btn-sm btn-outline-secondary"
                                    onClick={fetchQuestions}
                                    disabled={loading}
                                    title="Refresh"
                                >
                                    <CIcon icon={cilReload} />
                                </button>
                                <button
                                    type="button"
                                    className="btn btn-sm btn-primary"
                                    onClick={() => setShowAdd(v => !v)}
                                >
                                    <CIcon icon={showAdd ? cilX : cilPlus} className="me-1" />
                                    {showAdd ? "Cancel" : "Add Question"}
                                </button>
                            </div>
                        </div>

                        <div className="mt-2 d-flex flex-wrap gap-2 align-items-center">
                            {(contexts.length ? contexts : DEFAULT_CONTEXTS).map(ctx => {
                                const slug = String(ctx.option_name || '').toLowerCase()
                                const isActive = slug === activeContext
                                return (
                                    <button
                                        key={slug}
                                        type="button"
                                        className={`btn btn-sm ${isActive ? 'btn-dark' : 'btn-outline-secondary'}`}
                                        onClick={() => setActiveContext(slug)}
                                        disabled={loading}
                                        title="Switch question context"
                                    >
                                        {slug}
                                    </button>
                                )
                            })}
                        </div>

                        {showAdd && (
                            <div className="border rounded p-3 mt-3 bg-white shadow-sm">
                                <h6 className="fw-semibold mb-3">New Question</h6>
                                <div className="row g-2">
                                    <div className="col-md-4">
                                        <label className="form-label small fw-semibold">
                                            Question Text <span className="text-danger">*</span>
                                        </label>
                                        <input
                                            type="text" className={`form-control form-control-sm ${addAttempted && !newQ.text?.trim() ? "is-invalid" : ""}`}
                                            placeholder="e.g. Is the screen cracked?"
                                            value={newQ.text}
                                            onChange={e => setNewQ(p => ({ ...p, text: e.target.value }))}
                                        />
                                    </div>
                                    <div className="col-md-2">
                                        <label className="form-label small fw-semibold">Description</label>
                                        <input
                                            type="text" className="form-control form-control-sm"
                                            placeholder="Helper text shown below question"
                                            value={newQ.description}
                                            onChange={e => setNewQ(p => ({ ...p, description: e.target.value }))}
                                        />
                                    </div>
                                    <div className="col-md-3">
                                        <label className="form-label small fw-semibold">
                                            Input Type <span className="text-danger">*</span>
                                        </label>
                                        <select
                                            className="form-select form-select-sm"
                                            value={newQ.input_type}
                                            onChange={e => setNewQ(p => ({ ...p, input_type: e.target.value }))}
                                        >
                                            {INPUT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                                        </select>
                                    </div>
                                    <div className="col-md-2">
                                        <label className="form-label small fw-semibold">Context</label>
                                        <select
                                            className="form-select form-select-sm"
                                            value={newQ.context || activeContext}
                                            onChange={e => setNewQ(p => ({ ...p, context: e.target.value }))}
                                        >
                                            {(contexts.length ? contexts : DEFAULT_CONTEXTS).map(ctx => (
                                                <option key={ctx.option_name} value={String(ctx.option_name).toLowerCase()}>
                                                    {String(ctx.option_name).toLowerCase()}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="col-md-2">
                                        <label className="form-label small fw-semibold">Sort Order</label>
                                        <div className="form-control form-control-sm bg-light text-muted" style={{ cursor: "default" }}>
                                            # {nextSortIndex}
                                            <span className="ms-1 text-success small">(auto)</span>
                                        </div>
                                    </div>
                                    <div className="col-12">
                                        <label className="form-label small fw-semibold">
                                            Map to Categories <span className="text-danger">*</span>
                                        </label>
                                        <div className={`d-flex flex-wrap gap-2 p-2 rounded ${addAttempted && (newQ.category_slugs ?? []).length === 0 ? "border border-danger" : ""}`}>
                                            {categories.map(c => (
                                                <button
                                                    key={c.slug}
                                                    type="button"
                                                    className={`btn btn-sm ${(newQ.category_slugs ?? []).includes(c.slug) ? "btn-primary" : "btn-outline-secondary"}`}
                                                    onClick={() => toggleCategory(c.slug)}
                                                >
                                                    {c.name}
                                                </button>
                                            ))}
                                        </div>
                                        {addAttempted && (newQ.category_slugs ?? []).length === 0 && (
                                            <div className="text-danger small mt-1">Select at least one category.</div>
                                        )}
                                    </div>
                                </div>
                                <div className="d-flex gap-2 mt-3 justify-content-end">
                                    <button className="btn btn-sm btn-outline-secondary" onClick={() => setShowAdd(false)}>
                                        <CIcon icon={cilX} className="me-1" /> Cancel
                                    </button>
                                    <button
                                        className="btn btn-sm btn-success"
                                        onClick={handleCreateQuestion}
                                        disabled={saving}
                                    >
                                        <CIcon icon={cilCheck} className="me-1" />
                                        {saving ? "Saving..." : "Save"}
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                }
                columns={[
                    {
                        key: 'sort_index',
                        label: 'Order',
                        headerStyle: { width: 80 },
                        render: (q) => {
                            const qId = String(q.id)
                            const isEditing = editingId === qId
                            if (!isEditing) {
                                return (
                                    <div className="text-center">
                                        <span className="badge bg-light text-dark border">{q.sort_index}</span>
                                    </div>
                                )
                            }

                            return (
                                <input
                                    type="number"
                                    className="form-control form-control-sm"
                                    style={{ width: 65 }}
                                    value={editData.sort_index}
                                    min="1"
                                    onChange={e => setEditData(p => ({ ...p, sort_index: e.target.value }))}
                                />
                            )
                        },
                    },
                    {
                        key: 'question',
                        label: 'Question',
                        cellClassName: 'text-start',
                        render: (q) => {
                            const qId = String(q.id)
                            const isConditional = conditionalQIds.has(qId)
                            const triggeredBy = isConditional ? getTriggeredBy(qId) : []
                            const isEditing = editingId === qId

                            if (isEditing) {
                                return (
                                    <>
                                        <input
                                            type="text"
                                            className="form-control form-control-sm mb-1"
                                            value={editData.text}
                                            onChange={e => setEditData(p => ({ ...p, text: e.target.value }))}
                                        />
                                        <input
                                            type="text"
                                            className="form-control form-control-sm"
                                            placeholder="Description (optional)"
                                            value={editData.description}
                                            onChange={e => setEditData(p => ({ ...p, description: e.target.value }))}
                                        />
                                    </>
                                )
                            }

                            return (
                                <>
                                    <div className="d-flex align-items-center gap-2 flex-wrap">
                                        <span className="fw-semibold">{q.text}</span>
                                        {isConditional && (
                                            <span
                                                className="badge bg-secondary fw-normal"
                                                style={{ fontSize: "0.68rem" }}
                                                title="This question is shown conditionally — only when a specific option is selected"
                                            >
                                                conditional
                                            </span>
                                        )}
                                    </div>
                                    {q.description && <small className="text-muted d-block">{q.description}</small>}
                                    {isConditional && triggeredBy.length > 0 && (
                                        <div className="mt-1 d-flex flex-wrap gap-1">
                                            {triggeredBy.map((t, i) => (
                                                <small key={i} className="text-muted">
                                                    <span className="badge bg-light text-secondary border" style={{ fontSize: "0.65rem" }}>
                                                        Q#{t.fromQuestion.sort_index} &rsaquo; {t.option.text}
                                                    </span>
                                                </small>
                                            ))}
                                        </div>
                                    )}
                                </>
                            )
                        },
                    },
                    {
                        key: 'input_type',
                        label: 'Type',
                        render: (q) => {
                            const qId = String(q.id)
                            const isEditing = editingId === qId
                            if (!isEditing) return inputTypeBadge(q.input_type)

                            return (
                                <select
                                    className="form-select form-select-sm"
                                    value={editData.input_type}
                                    onChange={e => setEditData(p => ({ ...p, input_type: e.target.value }))}
                                >
                                    {INPUT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                                </select>
                            )
                        },
                    },
                    {
                        key: 'context',
                        label: 'Context',
                        headerStyle: { width: 120 },
                        render: (q) => {
                            const qId = String(q.id)
                            const isEditing = editingId === qId
                            if (!isEditing) return contextBadge(q.context_label) || <span className="text-muted small">—</span>

                            return (
                                <select
                                    className="form-select form-select-sm"
                                    value={editData.context || activeContext}
                                    onChange={e => setEditData(p => ({ ...p, context: e.target.value }))}
                                >
                                    {(contexts.length ? contexts : DEFAULT_CONTEXTS).map(ctx => (
                                        <option key={ctx.option_name} value={String(ctx.option_name).toLowerCase()}>
                                            {String(ctx.option_name).toLowerCase()}
                                        </option>
                                    ))}
                                </select>
                            )
                        },
                    },
                    {
                        key: 'options',
                        label: 'Options',
                        render: (q) => (
                            <span className="badge bg-secondary rounded-pill">{(q.options ?? []).length}</span>
                        ),
                    },
                    {
                        key: 'categories',
                        label: 'Categories',
                        render: (q) => {
                            const qId = String(q.id)
                            const isEditing = editingId === qId
                            if (!isEditing) {
                                return (
                                    <div className="d-flex flex-wrap gap-1">
                                        {(q.categories ?? []).length > 0
                                            ? (q.categories).map(c => (
                                                <span key={c.id ?? c.slug} className="badge bg-light text-dark border">
                                                    {c.name}
                                                </span>
                                            ))
                                            : <span className="text-muted small">None</span>
                                        }
                                    </div>
                                )
                            }

                            return (
                                <div className="d-flex flex-wrap gap-1">
                                    {categories.map(c => (
                                        <button
                                            key={c.slug}
                                            type="button"
                                            className={`btn btn-sm ${(editData.category_slugs ?? []).includes(c.slug) ? "btn-primary" : "btn-outline-secondary"}`}
                                            onClick={() => toggleEditCategory(c.slug)}
                                            title="Toggle category"
                                        >
                                            {c.name}
                                        </button>
                                    ))}
                                </div>
                            )
                        },
                    },
                    {
                        key: 'actions',
                        label: 'Actions',
                        render: (q) => {
                            const qId = String(q.id)
                            const isExpanded = expandedId === qId
                            const isEditing = editingId === qId

                            if (isEditing) {
                                return (
                                    <div className="d-flex gap-1">
                                        <button
                                            type="button"
                                            className="btn btn-sm btn-success"
                                            onClick={handleUpdateQuestion}
                                            disabled={saving || !editData.text?.trim()}
                                            title="Save"
                                        >
                                            <CIcon icon={cilCheck} />
                                        </button>
                                        <button
                                            type="button"
                                            className="btn btn-sm btn-outline-secondary"
                                            onClick={() => setEditingId(null)}
                                            title="Cancel"
                                        >
                                            <CIcon icon={cilX} />
                                        </button>
                                    </div>
                                )
                            }

                            return (
                                <div className="d-flex gap-1">
                                    <button
                                        type="button"
                                        className="btn btn-sm btn-outline-warning"
                                        onClick={() => startEditing(q)}
                                        title="Edit question"
                                    >
                                        <CIcon icon={cilPencil} />
                                    </button>
                                    <button
                                        type="button"
                                        className={`btn btn-sm ${isExpanded ? "btn-primary" : "btn-outline-info"}`}
                                        onClick={() => toggleExpand(q)}
                                        title="Manage Options & Conditions"
                                    >
                                        <CIcon icon={cilChevronRight} />
                                    </button>
                                    <button
                                        type="button"
                                        className="btn btn-sm btn-outline-danger"
                                        onClick={() => handleDeleteQuestion(qId)}
                                        title="Deactivate"
                                    >
                                        <CIcon icon={cilTrash} />
                                    </button>
                                </div>
                            )
                        },
                    },
                ]}
                rows={filteredQuestions}
                rowKey={(q) => q.id}
                getRowClassName={(q) => {
                    const qId = String(q.id)
                    if (editingId === qId) return 'table-warning'
                    if (expandedId === qId) return 'table-active'
                    if (conditionalQIds.has(qId)) return 'table-light'
                    return ''
                }}
                rowExpansion={{
                    isExpanded: (q) => {
                        const qId = String(q.id)
                        if (editingId === qId) return false
                        return expandedId === qId
                    },
                    cellClassName: 'bg-light p-3',
                    rowClassName: '',
                    render: (q) => {
                        const qId = String(q.id)
                        return (
                            <div className="row g-3">
                                {/* Options */}
                                <div className="col-md-5">
                                    <h6 className="fw-bold mb-2">
                                        Options
                                        {q.input_type === "yes_no" && (
                                            <span className="ms-2 badge bg-secondary fw-normal" style={{ fontSize: "0.7rem" }}>
                                                Fixed: Yes / No
                                            </span>
                                        )}
                                    </h6>
                                    {(() => {
                                        const opts = getEffectiveOptions(q);
                                        if (opts.length === 0) return (
                                            <p className="text-muted small mb-2">No options yet.</p>
                                        );
                                        return (
                                            <table className="table table-sm table-bordered mb-2">
                                                <thead className="table-light">
                                                    <tr>
                                                        <th style={{ width: 60 }}>SR.NO</th>
                                                        <th>Text</th>
                                                        <th>Deduction (&#37;)</th>
                                                        <th style={{ width: 86 }}>Image</th>
                                                        <th>Shows</th>
                                                        {q.input_type !== "yes_no" && <th />}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {opts.map((o, idx) => {
                                                        const showsQs = (o.show ?? []).map(sid =>
                                                            questions.find(oq => String(oq.id) === String(sid))
                                                        ).filter(Boolean);
                                                        const isYesNo = q.input_type === "yes_no";
                                                        const canEditDeduction = !!o.id;
                                                        const draftKey = String(o.id ?? "");
                                                        const draftVal = canEditDeduction
                                                            ? (optDeductionDraft[draftKey] ?? o.price_deduction ?? 0)
                                                            : (o.price_deduction ?? 0);
                                                        return (
                                                            <tr key={o.id ?? `syn-${idx}`} className={o._synthetic ? "table-secondary" : ""}>
                                                                <td className="text-muted small text-center">{o.sort_index}</td>
                                                                <td>
                                                                    {o.text}
                                                                    {o._synthetic && (
                                                                        <span className="ms-1 text-muted" style={{ fontSize: "0.7rem" }}>(auto)</span>
                                                                    )}
                                                                </td>
                                                                <td className="text-danger">
                                                                    {isYesNo ? (
                                                                        <div className="d-flex align-items-center gap-1">
                                                                            <input
                                                                                type="number"
                                                                                className="form-control form-control-sm"
                                                                                style={{ maxWidth: 95 }}
                                                                                min="0"
                                                                                max="100"
                                                                                step="0.01"
                                                                                disabled={!canEditDeduction}
                                                                                value={draftVal}
                                                                                onChange={e => {
                                                                                    if (!canEditDeduction) return;
                                                                                    setOptDeductionDraft(p => ({ ...p, [draftKey]: e.target.value }));
                                                                                }}
                                                                            />
                                                                            <span className="small text-muted">&#37;</span>
                                                                            <button
                                                                                type="button"
                                                                                className="btn btn-sm btn-outline-success p-0 px-1"
                                                                                disabled={!canEditDeduction || savingDeductionId === draftKey}
                                                                                onClick={() => handleUpdateOptionDeduction(o)}
                                                                                title="Save deduction"
                                                                            >
                                                                                <CIcon icon={cilCheck} style={{ width: 14, height: 14 }} />
                                                                            </button>
                                                                        </div>
                                                                    ) : (
                                                                        <>
                                                                            {o.price_deduction > 0 ? `${Number(o.price_deduction).toLocaleString()}` : "0"}&#37;
                                                                        </>
                                                                    )}
                                                                </td>
                                                                <td className="text-center">
                                                                    {o?.option_image_url ? (
                                                                        <div className="d-flex align-items-center justify-content-center gap-1">
                                                                            <img
                                                                                src={import.meta.env.VITE_API_URL + 'uploads/' + o.option_image_url}
                                                                                alt=""
                                                                                className="rounded border"
                                                                                style={{ width: 44, height: 44, objectFit: 'cover' }}
                                                                            />
                                                                            {q.input_type !== 'yes_no' && o?.id && (
                                                                                <button
                                                                                    type="button"
                                                                                    className="btn btn-sm btn-outline-secondary p-0 px-1"
                                                                                    onClick={() => handleClearOptionImage(o.id)}
                                                                                    disabled={uploadingOptImage}
                                                                                    title="Remove image"
                                                                                >
                                                                                    <CIcon icon={cilX} style={{ width: 14, height: 14 }} />
                                                                                </button>
                                                                            )}
                                                                        </div>
                                                                    ) : (
                                                                        <span className="text-muted small">—</span>
                                                                    )}
                                                                </td>
                                                                <td>
                                                                    {showsQs.length > 0
                                                                        ? showsQs.map(sq => (
                                                                            <span key={sq.id} className="badge bg-warning text-dark me-1" style={{ fontSize: "0.65rem" }}>
                                                                                Q#{sq.sort_index}
                                                                            </span>
                                                                        ))
                                                                        : <span className="text-muted small">None</span>
                                                                    }
                                                                </td>
                                                                {q.input_type !== "yes_no" && (
                                                                    <td>
                                                                        <button
                                                                            type="button"
                                                                            className="btn btn-sm btn-outline-danger p-0 px-1"
                                                                            onClick={() => handleDeleteOption(o.id)}
                                                                            disabled={!o.id}
                                                                            title="Delete option"
                                                                        >
                                                                            <CIcon icon={cilTrash} style={{ width: 14, height: 14 }} />
                                                                        </button>
                                                                    </td>
                                                                )}
                                                            </tr>
                                                        );
                                                    })}
                                                </tbody>
                                            </table>
                                        );
                                    })()}

                                    {q.input_type !== "yes_no" && (
                                        <div className="border rounded p-2 bg-white mb-2">
                                            <div className="small fw-semibold mb-1">Attach option image (optional)</div>
                                            <div className="d-flex gap-2 align-items-center flex-wrap">
                                                <select
                                                    className="form-select form-select-sm"
                                                    style={{ maxWidth: 220 }}
                                                    value={optImageTargetId}
                                                    onChange={e => setOptImageTargetId(e.target.value)}
                                                >
                                                    <option value="">Select option...</option>
                                                    {(q.options ?? []).map(o => (
                                                        <option key={o.id} value={o.id}>
                                                            {o.text}{o?.option_image_url ? ' (has image)' : ''}
                                                        </option>
                                                    ))}
                                                </select>
                                                <input
                                                    type="file"
                                                    className="form-control form-control-sm"
                                                    accept="image/*"
                                                    style={{ maxWidth: 260 }}
                                                    onChange={e => setOptImageFile(e.target.files?.[0] || null)}
                                                />
                                                <button
                                                    type="button"
                                                    className="btn btn-sm btn-outline-success"
                                                    onClick={handleAttachOptionImage}
                                                    disabled={uploadingOptImage || !optImageTargetId || !optImageFile}
                                                    title="Upload & attach"
                                                >
                                                    {uploadingOptImage ? 'Uploading...' : 'Attach'}
                                                </button>
                                            </div>
                                            <div className="text-muted small mt-1">Uploads to Images and links via option_image_id.</div>
                                        </div>
                                    )}

                                    {q.input_type === "yes_no" ? (
                                        <p className="text-muted small mb-0">
                                            Yes / No options are system-managed and readonly — use them to wire conditions below.
                                        </p>
                                    ) : (
                                        <div className="d-flex gap-2">
                                            <input
                                                type="text" className="form-control form-control-sm"
                                                placeholder="Option text"
                                                value={newOpt.text}
                                                onChange={e => setNewOpt(p => ({ ...p, text: e.target.value }))}
                                            />
                                            <input
                                                type="number" className="form-control form-control-sm" style={{ maxWidth: 90 }}
                                                placeholder="% Deduct"
                                                min="0" max="100" step="0.01"
                                                value={newOpt.price_deduction}
                                                onChange={e => setNewOpt(p => ({ ...p, price_deduction: e.target.value }))}
                                            />
                                            <button
                                                type="button"
                                                className="btn btn-sm btn-success"
                                                onClick={() => handleAddOption(qId)}
                                                disabled={savingOpt || !newOpt.text?.trim()}
                                                title="Add option"
                                            >
                                                <CIcon icon={cilPlus} />
                                            </button>
                                        </div>
                                    )}
                                </div>

                                {/* Conditions */}
                                <div className="col-md-4">
                                    <h6 className="fw-bold mb-2">Conditions</h6>
                                    <small className="text-muted d-block mb-2">
                                        When an option is selected, show a question that comes <strong>after</strong> this one.
                                    </small>

                                    {(() => {
                                        const outgoing = getOutgoingConditions(q);
                                        if (outgoing.length === 0) return (
                                            <p className="text-muted small mb-2">No conditions yet.</p>
                                        );
                                        return outgoing.map(({ option: o, shownQuestion: sq }, i) => (
                                            <div key={i} className="d-flex align-items-center gap-1 mb-1 small">
                                                <span className="badge bg-info text-dark">{o.text}</span>
                                                <CIcon icon={cilArrowRight} style={{ width: 12 }} />
                                                <span className="badge bg-warning text-dark">
                                                    Q#{sq.sort_index} {sq.text}
                                                </span>
                                                <button
                                                    type="button"
                                                    className="btn btn-sm p-0 px-1 btn-outline-danger ms-auto"
                                                    onClick={() => handleDeleteCondition(o.id, sq.id)}
                                                    title="Remove condition"
                                                >
                                                    <CIcon icon={cilX} style={{ width: 12, height: 12 }} />
                                                </button>
                                            </div>
                                        ));
                                    })()}

                                    <div className="d-flex gap-1 mt-2">
                                        <select
                                            className="form-select form-select-sm"
                                            value={newCond.trigger_option_id}
                                            onChange={e => setNewCond(p => ({ ...p, trigger_option_id: e.target.value }))}
                                        >
                                            <option value="">If option...</option>
                                            {getEffectiveOptions(q).map((o, idx) => (
                                                <option
                                                    key={o.id ?? `syn-${idx}`}
                                                    value={o.id ?? ""}
                                                    disabled={!o.id}
                                                >
                                                    {o.text}{o._synthetic ? " (pending...)" : ""}
                                                </option>
                                            ))}
                                        </select>
                                        <select
                                            className="form-select form-select-sm"
                                            value={newCond.show_question_id}
                                            onChange={e => setNewCond(p => ({ ...p, show_question_id: e.target.value }))}
                                        >
                                            <option value="">Then show...</option>
                                            {questions
                                                .filter(oq => String(oq.id) !== qId && (oq.sort_index ?? 0) > (q.sort_index ?? 0))
                                                .map(oq => (
                                                    <option key={oq.id} value={oq.id}>
                                                        [#{oq.sort_index}] {oq.text}
                                                    </option>
                                                ))
                                            }
                                        </select>
                                        <button
                                            type="button"
                                            className="btn btn-sm btn-success"
                                            onClick={handleAddCondition}
                                            disabled={!newCond.trigger_option_id || !newCond.show_question_id}
                                            title="Add condition"
                                        >
                                            <CIcon icon={cilLink} />
                                        </button>
                                    </div>
                                </div>

                                {/* Category Mapping */}
                                <div className="col-md-3">
                                    <h6 className="fw-bold mb-2">Categories</h6>
                                    <div className="d-flex flex-wrap gap-1 mb-2">
                                        {(q.categories ?? []).length > 0
                                            ? (q.categories).map(c => (
                                                <span key={c.id ?? c.slug} className="badge bg-primary d-flex align-items-center gap-1">
                                                    {c.name}
                                                    <button
                                                        type="button"
                                                        className="btn-close btn-close-white p-0 ms-1"
                                                        style={{ fontSize: "0.5rem" }}
                                                        onClick={() => handleUnmapCategory(c.id, qId)}
                                                        title="Unmap"
                                                    />
                                                </span>
                                            ))
                                            : <span className="text-muted small">No categories mapped.</span>
                                        }
                                    </div>
                                    <div className="d-flex gap-1">
                                        <select
                                            className="form-select form-select-sm"
                                            value={mapCatSlug}
                                            onChange={e => setMapCatSlug(e.target.value)}
                                        >
                                            <option value="">Add category...</option>
                                            {categories
                                                .filter(c => !(q.categories ?? []).find(qc => qc.id === c.id || qc.slug === c.slug))
                                                .map(c => (
                                                    <option key={c.slug} value={c.slug}>{c.name}</option>
                                                ))
                                            }
                                        </select>
                                        <button
                                            type="button"
                                            className="btn btn-sm btn-success"
                                            onClick={() => handleMapCategory(qId)}
                                            disabled={!mapCatSlug}
                                            title="Map"
                                        >
                                            <CIcon icon={cilPlus} />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        )
                    },
                }}
                emptyText={
                    questions.length === 0
                        ? 'No questions yet. Add one above.'
                        : 'No questions match your filters.'
                }
                footerLeft={
                    <div className="text-muted small d-flex gap-3 flex-wrap align-items-center">
                        <span>Total: <strong>{questions.length}</strong> question{questions.length !== 1 ? "s" : ""}</span>
                        {conditionalQIds.size > 0 && (
                            <span>{conditionalQIds.size} conditional</span>
                        )}
                        {hasActiveFilters && (
                            <span className="text-primary">Filtered: {filteredQuestions.length} shown</span>
                        )}
                        {hasActiveFilters && filteredQuestions.length === 0 && (
                            <button
                                type="button"
                                className="btn btn-sm btn-outline-secondary"
                                onClick={clearFilters}
                            >
                                Clear Filters
                            </button>
                        )}
                    </div>
                }
            />
        </div>
    );
}

