import React, { useEffect, useRef } from 'react'
import { NavLink } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import {
  CContainer,
  CDropdown,
  CDropdownItem,
  CDropdownDivider,
  CDropdownHeader,
  CDropdownMenu,
  CDropdownToggle,
  CHeader,
  CHeaderNav,
  CHeaderToggler,
  CNavLink,
  CNavItem,
  useColorModes,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilBell,
  cilContrast,
  cilEnvelopeOpen,
  cilList,
  cilMenu,
  cilMoon,
  cilSun,
} from '@coreui/icons'

import { AppBreadcrumb } from './index'
import { AppHeaderDropdown } from './header/index'

const AppHeader = () => {
  const headerRef = useRef()
  const { colorMode, setColorMode } = useColorModes('coreui-free-react-admin-template-theme')

  const dispatch = useDispatch()
  const sidebarShow = useSelector((state) => state.sidebarShow)
  const headerColorScheme = useSelector((state) => state.headerColorScheme || 'auto')
  const sidebarColorScheme = useSelector((state) => state.sidebarColorScheme || 'auto')

  const resolvedBaseScheme = (() => {
    if (colorMode === 'dark') return 'dark'
    if (colorMode === 'light') return 'light'
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  })()

  const resolvedHeaderScheme = headerColorScheme === 'auto' ? resolvedBaseScheme : headerColorScheme

  const setPref = (key, value) => {
    try {
      window.localStorage.setItem(key, value)
    } catch {
      // ignore
    }
  }

  useEffect(() => {
    const handleScroll = () => {
      headerRef.current &&
        headerRef.current.classList.toggle('shadow-sm', document.documentElement.scrollTop > 0)
    }

    document.addEventListener('scroll', handleScroll)
    return () => document.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <CHeader
      position="sticky"
      className="mb-4 p-0"
      ref={headerRef}
      colorscheme={resolvedHeaderScheme}
    >
      <CContainer className="border-bottom px-4" fluid>
        <CHeaderToggler
          onClick={() => dispatch({ type: 'set', sidebarShow: !sidebarShow })}
          style={{ marginInlineStart: '-14px' }}
        >
          <CIcon icon={cilMenu} size="lg" />
        </CHeaderToggler>
        <CHeaderNav className="d-none d-md-flex">
          <CNavItem>
            <CNavLink to="/dashboard" as={NavLink}>
              Dashboard
            </CNavLink>
          </CNavItem>
          <CNavItem>
            <CNavLink href="#">Settings</CNavLink>
          </CNavItem>
        </CHeaderNav>
        <CHeaderNav className="ms-auto">

          <CNavItem>
            <CNavLink href="#">
              <CIcon icon={cilBell} size="lg" /> {/* cilList */}
            </CNavLink>
          </CNavItem>
        </CHeaderNav>
        <CHeaderNav>
          <li className="nav-item py-1">
            <div className="vr h-100 mx-2 text-body text-opacity-75"></div>
          </li>
          <CDropdown variant="nav-item" placement="bottom-end">
            <CDropdownToggle caret={false}>
              {colorMode === 'dark' ? (
                <CIcon icon={cilMoon} size="lg" />
              ) : colorMode === 'auto' ? (
                <CIcon icon={cilContrast} size="lg" />
              ) : (
                <CIcon icon={cilSun} size="lg" />
              )}
            </CDropdownToggle>
            <CDropdownMenu>
              <CDropdownHeader className="bg-body-secondary fw-semibold">App Theme</CDropdownHeader>
              <CDropdownItem
                active={colorMode === 'light'}
                className="d-flex align-items-center"
                as="button"
                type="button"
                onClick={() => setColorMode('light')}
              >
                <CIcon className="me-2" icon={cilSun} size="lg" /> Light
              </CDropdownItem>
              <CDropdownItem
                active={colorMode === 'dark'}
                className="d-flex align-items-center"
                as="button"
                type="button"
                onClick={() => setColorMode('dark')}
              >
                <CIcon className="me-2" icon={cilMoon} size="lg" /> Dark
              </CDropdownItem>
              <CDropdownItem
                active={colorMode === 'auto'}
                className="d-flex align-items-center"
                as="button"
                type="button"
                onClick={() => setColorMode('auto')}
              >
                <CIcon className="me-2" icon={cilContrast} size="lg" /> Auto
              </CDropdownItem>

              <CDropdownDivider />
              <CDropdownHeader className="bg-body-secondary fw-semibold">Sidebar</CDropdownHeader>
              <CDropdownItem
                active={sidebarColorScheme === 'auto'}
                as="button"
                type="button"
                onClick={() => {
                  dispatch({ type: 'set', sidebarColorScheme: 'auto' })
                  setPref('resello_sidebarColorScheme', 'auto')
                }}
              >
                Follow theme
              </CDropdownItem>
              <CDropdownItem
                active={sidebarColorScheme === 'light'}
                as="button"
                type="button"
                onClick={() => {
                  dispatch({ type: 'set', sidebarColorScheme: 'light' })
                  setPref('resello_sidebarColorScheme', 'light')
                }}
              >
                Light
              </CDropdownItem>
              <CDropdownItem
                active={sidebarColorScheme === 'dark'}
                as="button"
                type="button"
                onClick={() => {
                  dispatch({ type: 'set', sidebarColorScheme: 'dark' })
                  setPref('resello_sidebarColorScheme', 'dark')
                }}
              >
                Dark
              </CDropdownItem>

              <CDropdownDivider />
              <CDropdownHeader className="bg-body-secondary fw-semibold">Header</CDropdownHeader>
              <CDropdownItem
                active={headerColorScheme === 'auto'}
                as="button"
                type="button"
                onClick={() => {
                  dispatch({ type: 'set', headerColorScheme: 'auto' })
                  setPref('resello_headerColorScheme', 'auto')
                }}
              >
                Follow theme
              </CDropdownItem>
              <CDropdownItem
                active={headerColorScheme === 'light'}
                as="button"
                type="button"
                onClick={() => {
                  dispatch({ type: 'set', headerColorScheme: 'light' })
                  setPref('resello_headerColorScheme', 'light')
                }}
              >
                Light
              </CDropdownItem>
              <CDropdownItem
                active={headerColorScheme === 'dark'}
                as="button"
                type="button"
                onClick={() => {
                  dispatch({ type: 'set', headerColorScheme: 'dark' })
                  setPref('resello_headerColorScheme', 'dark')
                }}
              >
                Dark
              </CDropdownItem>
            </CDropdownMenu>
          </CDropdown>
          <li className="nav-item py-1">
            <div className="vr h-100 mx-2 text-body text-opacity-75"></div>
          </li>
          <AppHeaderDropdown />
        </CHeaderNav>
      </CContainer>
      <CContainer className="px-4" fluid>
        <AppBreadcrumb />
      </CContainer>
    </CHeader>
  )
}

export default AppHeader
